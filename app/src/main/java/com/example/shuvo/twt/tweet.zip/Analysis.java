package com.example.shuvo.twt;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Shuvo on 4/11/2017.
 */
public class Analysis extends AppCompatActivity {
    TextView textView;
    ScrollView scrollView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.analysis_layout);
        textView=(TextView)findViewById(R.id.textView);
        StringBuilder result = new StringBuilder();
        double r;
        try {
            FileInputStream fis = openFileInput("myFile");
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader bufferedReader = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                sb.append(line);
            }
           // textView.setText(sb);
            //StringBuilder result = MainTweet.main("reply", getApplicationContext().getApplicationContext());
            double d=Main.main(getApplicationContext().getApplicationContext());
            textView.setText("result is "+ d);

        }
        catch (IOException e){}

    }









}
